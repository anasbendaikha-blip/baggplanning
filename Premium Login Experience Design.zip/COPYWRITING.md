# Guide Copywriting Premium - PharmaCare

## 🎯 Principe de base
Ton : Calme, précis, haut de gamme, rassurant, sans pression commerciale

---

## 📝 TOFU - Découverte (Top of Funnel)

### Objectif
Compréhension immédiate + fluence cognitive + découverte de la valeur

### Textes

**Titre principal**
```
La plateforme qui simplifie votre pratique quotidienne
```

**Sous-titre**
```
Centralisez la gestion de votre officine et gagnez jusqu'à 15 heures par semaine.
```

**Titre de la carte de connexion**
```
Accédez à votre espace professionnel
```

**Sous-titre de la carte**
```
Gérez vos prescriptions, stocks et ordonnances en un seul endroit
```

**Features (bullets)**
- Gestion intelligente des stocks et péremptions
- Suivi des prescriptions et interactions médicamenteuses
- Tableau de bord analytique en temps réel

**CTA Principal**
```
Se connecter
```

**CTA Secondaire**
```
Créer un compte professionnel
```

---

## 📝 MOFU - Considération (Middle of Funnel)

### Objectif
Confiance + preuve sociale + réduction du risque

### Textes

**Titre principal**
```
Rejoignez les professionnels qui transforment leur pratique
```

**Sous-titre**
```
PharmaCare est la solution de référence pour plus de 12 000 pharmaciens et préparateurs en France.
```

**Titre de la carte de connexion**
```
Connectez-vous en toute sécurité
```

**Sous-titre de la carte**
```
Rejoignez plus de 12 000 professionnels de santé qui nous font confiance
```

**Statistiques (Stats Cards)**
- **12 000+** Utilisateurs actifs
- **2 400** Officines équipées
- **98%** Taux de satisfaction
- **15h** Gagnées par semaine

**Témoignage**
```
Quote: "PharmaCare a révolutionné notre gestion quotidienne. Les alertes de péremption et le suivi des stocks nous font gagner un temps précieux."

Auteur: Dr. Sophie Martin
Rôle: Pharmacienne titulaire, Paris 15e
Note: 5/5 étoiles
```

**Partenaires**
```
Texte: Approuvé et utilisé par
Logos: ONP • AP-HP • ARS • ANSM
```

---

## 📝 BOFU - Conversion (Bottom of Funnel)

### Objectif
Friction minimale + action immédiate + réassurance finale

### Textes

**Titre principal**
```
Bienvenue
```

**Sous-titre**
```
Accédez à tous vos outils professionnels en un clic.
```

**Titre de la carte de connexion**
```
Accéder à mon espace
```

**Sous-titre de la carte**
```
Reprenez là où vous vous êtes arrêté
```

**Features minimalistes**
- **Accès instantané** : Reprenez votre travail là où vous l'avez laissé
- **Sécurité maximale** : Vos données sont chiffrées de bout en bout
- **Disponible 24/7** : Accédez à votre espace depuis n'importe où

**Bandeau de confiance**
```
Titre: Protection des données certifiée
Détails: Conforme RGPD • Hébergement HDS • Chiffrement AES-256
```

---

## 🔒 Éléments de réassurance (tous variants)

### Trust Badges
- **Données chiffrées** (icône : Lock)
- **Conforme RGPD** (icône : Shield)
- **Certifié HDS** (icône : Check)

### Pied de page de la carte de connexion
```
Pas encore de compte ? Créer un compte professionnel
Besoin d'aide ?
```

---

## 📋 Labels & Placeholders de formulaire

### Champ Email
```
Label: Adresse email professionnelle *
Placeholder: prenom.nom@pharmacie.fr
Helper (si TOFU): Utilisez votre email professionnel
```

### Champ Mot de passe
```
Label: Mot de passe *
Placeholder: ••••••••
Helper (si TOFU): Minimum 8 caractères
```

### Checkbox
```
Label: Rester connecté
```

### Liens
```
Mot de passe oublié ?
Besoin d'aide ?
```

---

## ⚠️ Messages d'erreur (ton calme, aide corrective)

### Erreur email vide
```
Ce champ est requis
```

### Erreur email invalide
```
Veuillez saisir une adresse email valide
```

### Erreur mot de passe vide
```
Ce champ est requis
```

### Erreur combinaison invalide
```
Email ou mot de passe incorrect. Besoin d'aide ?
```

### Erreur compte verrouillé
```
Votre compte a été temporairement verrouillé pour des raisons de sécurité. 
Veuillez réinitialiser votre mot de passe ou contacter le support.
```

### Erreur serveur
```
Une erreur s'est produite. Veuillez réessayer dans quelques instants.
```

---

## ✅ Messages de succès

### Connexion réussie
```
Connexion réussie ! Redirection en cours...
```

### Email de réinitialisation envoyé
```
Un email de réinitialisation a été envoyé à votre adresse.
Vérifiez votre boîte de réception.
```

---

## 🔄 États de chargement

### Bouton de connexion
```
État normal: Se connecter
État chargement: Connexion en cours...
```

### Boutons SSO
```
Continuer avec Google
Continuer avec Microsoft
Continuer avec Apple
```

---

## 💡 Textes alternatifs de CTA (pour A/B testing)

### Variante 1 (Actuel)
```
Se connecter
```

### Variante 2 (Action orientée bénéfice)
```
Accéder à mon espace
```

### Variante 3 (Valeur)
```
Commencer ma session
```

### Variante 4 (Continuité - Zeigarnik)
```
Reprendre mon travail
```

---

## 🎨 Principes de neuromarketing appliqués

### 1. Fluence cognitive
- Phrases courtes et claires
- Une action principale par écran
- Hiérarchie visuelle évidente

### 2. Effet de halo (premium = confiance)
- Vocabulaire professionnel mais accessible
- Éviter le jargon inutile
- Finitions linguistiques soignées

### 3. Preuve sociale (MOFU)
- Chiffres précis et vérifiables
- Témoignages authentiques avec noms/rôles
- Logos de partenaires réels

### 4. Autorité (légitime)
- Certifications réelles (RGPD, HDS)
- Partenaires institutionnels
- Expertise affirmée mais humble

### 5. Réduction du risque / Aversion à la perte
- "Vos données restent privées"
- "Accès sécurisé"
- "Vous gardez le contrôle"
- Sans promesses non vérifiables

### 6. Engagement & cohérence
- "Reprenez là où vous vous êtes arrêté"
- "Accédez à votre espace"
- Confirmation de l'intention sans forcer

### 7. Effet de saillance (Von Restorff)
- Un seul CTA principal par carte
- Couleur accent cohérente
- Isolation visuelle

### 8. Framing positif
- Orientation bénéfices ("gagnez du temps")
- Pas de peur ou d'urgence artificielle
- Valeur avant action

### 9. Réciprocité authentique
- Proposition de valeur réelle
- Pas de "cadeaux" faux
- Service avant conversion

### 10. Zeigarnik (continuité)
- "Reprenez là où vous vous êtes arrêté"
- Pertinent pour utilisateurs existants

---

## 🚫 Interdictions strictes

❌ **PAS de :**
- Urgence artificielle ("Plus que 24h !", "Offre limitée !")
- Scarcity mensongère ("Plus que 3 places !")
- Cases précochées pour marketing
- Opt-in cachés
- Culpabilisation
- Promesses médicales non prouvées
- Allégations de santé non vérifiables
- Surpromesses ("Révolutionnez votre pratique en 1 jour")

✅ **OUI à :**
- Clarté absolue
- Transparence totale
- Bénéfices réels et mesurables
- Preuves vérifiables
- Respect du rythme de l'utilisateur
- Aide proactive
- Confiance construite, pas forcée

---

## 📱 Adaptations Responsive

### Mobile
- Titres plus courts (20-30 caractères max)
- Textes de CTA concis
- Priorité à l'essentiel

### Tablette
- Textes standards
- Layout adapté mais contenu identique

### Desktop
- Textes complets
- Possibilité d'enrichir avec helper texts

---

## 🌍 Conformité & Légal

### Mentions obligatoires
```
© 2026 PharmaCare. Tous droits réservés.
Conditions d'utilisation • Politique de confidentialité • RGPD
Hébergement certifié HDS (Hébergeur de Données de Santé)
```

### Disclaimer (si nécessaire)
```
PharmaCare est un outil d'aide à la gestion pharmaceutique. 
Il ne remplace pas le jugement professionnel du pharmacien.
```

---

## 🎯 Résumé des objectifs par variant

| Variant | Objectif principal | Tone | Focus |
|---------|-------------------|------|-------|
| **TOFU** | Compréhension | Pédagogue, accueillant | Clarté de la valeur |
| **MOFU** | Confiance | Rassurant, preuves | Réduction du risque |
| **BOFU** | Action | Direct, efficace | Friction minimale |

---

**Version:** 1.0  
**Date:** Janvier 2026  
**Marque:** PharmaCare  
**Secteur:** Pharmacie / Santé professionnelle
