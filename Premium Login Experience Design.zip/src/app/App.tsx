import React, { useState, useEffect } from 'react';
import { TOFUVariant } from './components/login/TOFUVariant';
import { MOFUVariant } from './components/login/MOFUVariant';
import { BOFUVariant } from './components/login/BOFUVariant';
import { ArrowLeft, ArrowRight, Info } from 'lucide-react';

type Variant = 'tofu' | 'mofu' | 'bofu';

const App: React.FC = () => {
  const [currentVariant, setCurrentVariant] = useState<Variant>('bofu');
  const [showInfo, setShowInfo] = useState(true);
  
  const variants: { key: Variant; label: string; description: string }[] = [
    { 
      key: 'tofu', 
      label: 'TOFU - Découverte', 
      description: 'Top of Funnel : Première découverte, clarification de la valeur' 
    },
    { 
      key: 'mofu', 
      label: 'MOFU - Considération', 
      description: 'Middle of Funnel : Preuves sociales, réduction du risque' 
    },
    { 
      key: 'bofu', 
      label: 'BOFU - Conversion', 
      description: 'Bottom of Funnel : Friction minimale, action immédiate' 
    }
  ];
  
  const currentIndex = variants.findIndex(v => v.key === currentVariant);
  const canGoPrev = currentIndex > 0;
  const canGoNext = currentIndex < variants.length - 1;
  
  const goToPrev = () => {
    if (canGoPrev) {
      setCurrentVariant(variants[currentIndex - 1].key);
    }
  };
  
  const goToNext = () => {
    if (canGoNext) {
      setCurrentVariant(variants[currentIndex + 1].key);
    }
  };
  
  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') {
        goToPrev();
      } else if (e.key === 'ArrowRight') {
        goToNext();
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentIndex]);
  
  const renderVariant = () => {
    switch (currentVariant) {
      case 'tofu':
        return <TOFUVariant />;
      case 'mofu':
        return <MOFUVariant />;
      case 'bofu':
        return <BOFUVariant />;
      default:
        return <BOFUVariant />;
    }
  };
  
  return (
    <div className="relative w-full h-screen overflow-hidden bg-[#1e293b]">
      {/* Navigation Controls - Fixed */}
      <div className="fixed top-0 left-0 right-0 z-50 bg-[#334155]/95 backdrop-blur-md border-b border-white/10 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 sm:py-4">
          <div className="flex items-center justify-between gap-2 sm:gap-4">
            {/* Info Section */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 sm:gap-3">
                <button
                  onClick={() => setShowInfo(!showInfo)}
                  className="p-1.5 sm:p-2 rounded-lg hover:bg-white/10 transition-colors shrink-0"
                >
                  <Info className="w-4 h-4 sm:w-5 sm:h-5 text-[#10b981]" strokeWidth={2} />
                </button>
                <div className="min-w-0">
                  <h3 className="text-xs sm:text-sm font-semibold text-white truncate">
                    {variants[currentIndex].label}
                  </h3>
                  {showInfo && (
                    <p className="hidden sm:block text-xs text-white/70 mt-0.5">
                      {variants[currentIndex].description}
                    </p>
                  )}
                </div>
              </div>
            </div>
            
            {/* Variant Pills */}
            <div className="flex items-center gap-1.5 sm:gap-2">
              {variants.map((variant) => (
                <button
                  key={variant.key}
                  onClick={() => setCurrentVariant(variant.key)}
                  className={`
                    px-2 sm:px-4 py-1.5 sm:py-2 rounded-lg text-xs sm:text-sm font-medium transition-all duration-200
                    ${currentVariant === variant.key 
                      ? 'bg-[#10b981] text-white shadow-md' 
                      : 'bg-white/10 text-white/70 hover:bg-white/20 hover:text-white'
                    }
                  `}
                >
                  {variant.label.split(' - ')[0]}
                </button>
              ))}
            </div>
            
            {/* Navigation Arrows */}
            <div className="hidden sm:flex items-center gap-2">
              <button
                onClick={goToPrev}
                disabled={!canGoPrev}
                className={`
                  p-2 rounded-lg transition-all duration-200
                  ${canGoPrev 
                    ? 'bg-white/10 text-white hover:bg-white/20' 
                    : 'bg-white/5 text-white/30 cursor-not-allowed'
                  }
                `}
              >
                <ArrowLeft className="w-5 h-5" strokeWidth={2} />
              </button>
              <button
                onClick={goToNext}
                disabled={!canGoNext}
                className={`
                  p-2 rounded-lg transition-all duration-200
                  ${canGoNext 
                    ? 'bg-white/10 text-white hover:bg-white/20' 
                    : 'bg-white/5 text-white/30 cursor-not-allowed'
                  }
                `}
              >
                <ArrowRight className="w-5 h-5" strokeWidth={2} />
              </button>
            </div>
          </div>
        </div>
      </div>
      
      {/* Information Banner */}
      {showInfo && (
        <div className="fixed top-16 sm:top-20 left-0 right-0 z-40 bg-[#10b981]/90 backdrop-blur-md border-b border-[#10b981]/30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2 sm:py-3">
            <div className="flex items-start gap-2 sm:gap-3">
              <Info className="hidden sm:block w-4 h-4 text-white mt-0.5 shrink-0" strokeWidth={2} />
              <div className="flex-1 min-w-0">
                <p className="text-xs sm:text-sm text-white leading-relaxed">
                  <strong className="hidden sm:inline">Style BaggPlanning</strong>
                  <span className="hidden sm:inline"> • </span>
                  Design minimaliste et moderne • 
                  <span className="hidden md:inline"> Background foncé • Carte centrale blanche • </span>
                  <span className="hidden lg:inline">Palette : Vert menthe (#10b981) + Bleu marine (#1e293b)</span>
                </p>
              </div>
              <button
                onClick={() => setShowInfo(false)}
                className="text-white hover:text-white/80 transition-colors text-lg font-medium shrink-0 leading-none"
              >
                ×
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Main Content */}
      <div className={`w-full h-full transition-all duration-300 ${showInfo ? 'pt-24 sm:pt-32' : 'pt-16 sm:pt-20'}`}>
        <div className="w-full h-full overflow-auto">
          {renderVariant()}
        </div>
      </div>
      
      {/* Keyboard Shortcuts Hint */}
      <div className="hidden sm:block fixed bottom-6 right-6 z-50 bg-white/10 backdrop-blur-md rounded-xl shadow-lg border border-white/20 px-4 py-3">
        <div className="flex items-center gap-4 text-xs text-white/70">
          <div className="flex items-center gap-2">
            <kbd className="px-2 py-1 bg-white/10 rounded border border-white/20 font-mono text-white">←</kbd>
            <span>Précédent</span>
          </div>
          <div className="flex items-center gap-2">
            <kbd className="px-2 py-1 bg-white/10 rounded border border-white/20 font-mono text-white">→</kbd>
            <span>Suivant</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;