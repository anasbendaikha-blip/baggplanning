import React, { useState } from 'react';
import { Eye, EyeOff, AlertCircle, CheckCircle2 } from 'lucide-react';

interface InputFieldProps {
  label: string;
  type?: 'text' | 'email' | 'password';
  placeholder?: string;
  value: string;
  onChange: (value: string) => void;
  error?: string;
  success?: boolean;
  helperText?: string;
  required?: boolean;
  autoComplete?: string;
}

export const InputField: React.FC<InputFieldProps> = ({
  label,
  type = 'text',
  placeholder,
  value,
  onChange,
  error,
  success,
  helperText,
  required = false,
  autoComplete
}) => {
  const [showPassword, setShowPassword] = useState(false);
  const [isFocused, setIsFocused] = useState(false);
  
  const inputType = type === 'password' && showPassword ? 'text' : type;
  
  const getBorderColor = () => {
    if (error) return 'border-[#ef4444] ring-[#ef4444]/20';
    if (success) return 'border-[#10b981] ring-[#10b981]/20';
    if (isFocused) return 'border-[#10b981] ring-[#10b981]/10';
    return 'border-[#e2e8f0] hover:border-[#cbd5e1]';
  };
  
  return (
    <div className="w-full space-y-2">
      <label 
        className="block text-sm font-medium text-[#1e293b]"
      >
        {label}
        {required && <span className="text-[#ef4444] ml-1">*</span>}
      </label>
      
      <div className="relative">
        <input
          type={inputType}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
          placeholder={placeholder}
          autoComplete={autoComplete}
          className={`
            w-full px-4 py-3 rounded-lg
            bg-[#f8fafc] border-2 
            text-[#1e293b] placeholder:text-[#94a3b8]
            transition-all duration-200
            focus:outline-none focus:ring-4
            ${getBorderColor()}
            ${type === 'password' ? 'pr-12' : ''}
            ${error || success ? 'pr-12' : ''}
          `}
        />
        
        {/* Password toggle */}
        {type === 'password' && (
          <button
            type="button"
            onClick={() => setShowPassword(!showPassword)}
            className="absolute right-4 top-1/2 -translate-y-1/2 text-[#64748b] hover:text-[#1e293b] transition-colors"
            tabIndex={-1}
          >
            {showPassword ? (
              <EyeOff className="w-5 h-5" strokeWidth={2} />
            ) : (
              <Eye className="w-5 h-5" strokeWidth={2} />
            )}
          </button>
        )}
        
        {/* Error/Success icons */}
        {error && type !== 'password' && (
          <AlertCircle className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#ef4444]" strokeWidth={2} />
        )}
        {success && type !== 'password' && (
          <CheckCircle2 className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#10b981]" strokeWidth={2} />
        )}
      </div>
      
      {/* Helper text / Error message */}
      {(error || helperText) && (
        <div className="flex items-start gap-1.5">
          {error && <AlertCircle className="w-4 h-4 text-[#ef4444] mt-0.5 shrink-0" strokeWidth={2} />}
          <p className={`text-sm ${error ? 'text-[#ef4444]' : 'text-[#64748b]'}`}>
            {error || helperText}
          </p>
        </div>
      )}
    </div>
  );
};