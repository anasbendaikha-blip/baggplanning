import React from 'react';
import { PharmacyLogo } from './PharmacyLogo';
import { LoginFormCard } from './LoginFormCard';

export const TOFUVariant: React.FC = () => {
  return (
    <div className="min-h-screen bg-[#1e293b] flex items-center justify-center p-6">
      <div className="w-full max-w-md space-y-8">
        {/* Logo & Title */}
        <PharmacyLogo showText={true} />
        
        {/* Login Card */}
        <LoginFormCard variant="tofu" />
        
        {/* Footer Links */}
        <div className="text-center space-y-3">
          <a 
            href="#" 
            className="text-sm text-white/70 hover:text-white transition-colors inline-block"
            onClick={(e) => e.preventDefault()}
          >
            Mot de passe oublié ?
          </a>
          <div className="text-sm text-white/50">
            Pas encore de compte ?{' '}
            <a 
              href="#" 
              className="text-[#10b981] hover:text-[#059669] font-medium transition-colors"
              onClick={(e) => e.preventDefault()}
            >
              Créer un compte
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
