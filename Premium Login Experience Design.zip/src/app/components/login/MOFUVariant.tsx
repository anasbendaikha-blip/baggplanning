import React from 'react';
import { PharmacyLogo } from './PharmacyLogo';
import { LoginFormCard } from './LoginFormCard';
import { Users, Building2, Star, Clock } from 'lucide-react';

export const MOFUVariant: React.FC = () => {
  const stats = [
    { icon: Users, value: '12k+', label: 'Utilisateurs actifs' },
    { icon: Building2, value: '2.4k', label: 'Pharmacies' },
    { icon: Star, value: '4.9/5', label: 'Satisfaction' },
    { icon: Clock, value: '15h', label: 'Économisées/sem' }
  ];
  
  return (
    <div className="min-h-screen bg-[#1e293b] flex items-center justify-center p-6">
      <div className="w-full max-w-5xl space-y-8">
        {/* Logo & Title */}
        <PharmacyLogo showText={true} className="mb-12" />
        
        <div className="grid lg:grid-cols-2 gap-8 items-start">
          {/* Left: Social Proof */}
          <div className="space-y-6 order-2 lg:order-1">
            {/* Stats */}
            <div className="grid grid-cols-2 gap-4">
              {stats.map((stat, index) => {
                const Icon = stat.icon;
                return (
                  <div 
                    key={index}
                    className="p-4 rounded-xl bg-white/10 backdrop-blur-sm border border-white/20 hover:bg-white/15 transition-all"
                  >
                    <Icon className="w-6 h-6 text-[#10b981] mb-2" strokeWidth={2} />
                    <p className="text-2xl font-bold text-white mb-1">
                      {stat.value}
                    </p>
                    <p className="text-sm text-white/70">
                      {stat.label}
                    </p>
                  </div>
                );
              })}
            </div>
            
            {/* Testimonial */}
            <div className="p-6 rounded-xl bg-white/10 backdrop-blur-sm border border-white/20">
              <div className="flex gap-1 mb-3">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-[#10b981] text-[#10b981]" strokeWidth={0} />
                ))}
              </div>
              <p className="text-white mb-4 leading-relaxed">
                "PharmaCare a révolutionné notre gestion quotidienne. Interface intuitive et gain de temps considérable !"
              </p>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-[#10b981] flex items-center justify-center text-white font-semibold">
                  SM
                </div>
                <div>
                  <p className="font-semibold text-white text-sm">Dr. Sophie Martin</p>
                  <p className="text-sm text-white/70">Pharmacienne titulaire</p>
                </div>
              </div>
            </div>
            
            {/* Trust Badges */}
            <div className="flex flex-wrap gap-3">
              <div className="px-4 py-2 rounded-lg bg-white/10 backdrop-blur-sm border border-white/20">
                <p className="text-sm text-white font-medium">🔒 Conforme RGPD</p>
              </div>
              <div className="px-4 py-2 rounded-lg bg-white/10 backdrop-blur-sm border border-white/20">
                <p className="text-sm text-white font-medium">🏥 Certifié HDS</p>
              </div>
              <div className="px-4 py-2 rounded-lg bg-white/10 backdrop-blur-sm border border-white/20">
                <p className="text-sm text-white font-medium">✅ Données chiffrées</p>
              </div>
            </div>
          </div>
          
          {/* Right: Login Card */}
          <div className="order-1 lg:order-2">
            <LoginFormCard variant="mofu" />
          </div>
        </div>
        
        {/* Footer */}
        <div className="text-center space-y-3">
          <a 
            href="#" 
            className="text-sm text-white/70 hover:text-white transition-colors inline-block"
            onClick={(e) => e.preventDefault()}
          >
            Mot de passe oublié ?
          </a>
          <div className="text-sm text-white/50">
            Pas encore de compte ?{' '}
            <a 
              href="#" 
              className="text-[#10b981] hover:text-[#059669] font-medium transition-colors"
              onClick={(e) => e.preventDefault()}
            >
              Créer un compte professionnel
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
