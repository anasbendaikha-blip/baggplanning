import React, { useState } from 'react';
import { InputField } from './InputField';
import { PrimaryButton } from './PrimaryButton';
import { DemoAccounts } from './DemoAccounts';
import { Hint } from './Hint';

interface LoginFormCardProps {
  variant: 'tofu' | 'mofu' | 'bofu';
  onSubmit?: (email: string, password: string) => void;
  className?: string;
}

export const LoginFormCard: React.FC<LoginFormCardProps> = ({ 
  variant,
  onSubmit,
  className = '' 
}) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [emailError, setEmailError] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [loading, setLoading] = useState(false);
  
  const validateEmail = (value: string) => {
    if (!value) {
      setEmailError('');
      return false;
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(value)) {
      setEmailError('Veuillez saisir une adresse email valide');
      return false;
    }
    setEmailError('');
    return true;
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const isEmailValid = validateEmail(email);
    
    if (!password) {
      setPasswordError('Ce champ est requis');
      return;
    } else {
      setPasswordError('');
    }
    
    if (!isEmailValid) return;
    
    setLoading(true);
    
    // Simulation d'une connexion
    setTimeout(() => {
      setLoading(false);
      if (onSubmit) {
        onSubmit(email, password);
      }
    }, 1500);
  };
  
  const handleDemoSelect = (demoEmail: string) => {
    setEmail(demoEmail);
    setEmailError('');
  };
  
  const showDemoAccounts = variant === 'mofu' || variant === 'bofu';
  const showHint = variant === 'tofu';
  
  return (
    <div className={`w-full max-w-md p-8 rounded-2xl bg-white shadow-2xl ${className}`}>
      {/* Form */}
      <form onSubmit={handleSubmit} className="space-y-5">
        <InputField
          label="Email"
          type="email"
          placeholder="votre@email.com"
          value={email}
          onChange={(value) => {
            setEmail(value);
            if (emailError) validateEmail(value);
          }}
          error={emailError}
          required
          autoComplete="email"
        />
        
        <InputField
          label="Mot de passe"
          type="password"
          placeholder="••••••••"
          value={password}
          onChange={(value) => {
            setPassword(value);
            if (passwordError && value) setPasswordError('');
          }}
          error={passwordError}
          required
          autoComplete="current-password"
        />
        
        {/* Submit button */}
        <PrimaryButton
          type="submit"
          variant="primary"
          size="lg"
          fullWidth
          loading={loading}
          showIcon={!loading}
        >
          {loading ? 'Connexion en cours...' : 'Se connecter'}
        </PrimaryButton>
      </form>
      
      {/* Demo Accounts Section */}
      {showDemoAccounts && (
        <>
          <div className="my-6 relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-[#e2e8f0]" />
            </div>
            <div className="relative flex justify-center">
              <span className="px-3 text-xs text-[#94a3b8] bg-white font-medium">
                ou
              </span>
            </div>
          </div>
          
          <DemoAccounts onSelectDemo={handleDemoSelect} />
        </>
      )}
      
      {/* Hint Section (TOFU only) */}
      {showHint && (
        <Hint className="mt-6">
          <strong>Astuce</strong> : Cliquez sur "Utiliser" pour remplir automatiquement les identifiants de démo, puis cliquez sur "Se connecter".
        </Hint>
      )}
      
      {/* Hint Section with link (MOFU/BOFU) */}
      {showDemoAccounts && (
        <Hint className="mt-6">
          <strong>Astuce</strong> : Cliquez sur <span className="font-semibold">"Utiliser"</span> pour remplir automatiquement les identifiants de démo, puis cliquez sur <span className="font-semibold">"Se connecter"</span>.
        </Hint>
      )}
    </div>
  );
};
