import React from 'react';

interface SocialLoginButtonProps {
  provider: 'google' | 'microsoft' | 'apple';
  onClick?: () => void;
  className?: string;
}

export const SocialLoginButton: React.FC<SocialLoginButtonProps> = ({ 
  provider, 
  onClick,
  className = '' 
}) => {
  const providerConfig = {
    google: {
      name: 'Google',
      icon: (
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
          <path d="M19.6 10.227c0-.709-.064-1.39-.182-2.045H10v3.868h5.382a4.6 4.6 0 01-1.996 3.018v2.51h3.232c1.891-1.742 2.982-4.305 2.982-7.35z" fill="#4285F4"/>
          <path d="M10 20c2.7 0 4.964-.895 6.618-2.423l-3.232-2.509c-.895.6-2.04.955-3.386.955-2.605 0-4.81-1.76-5.595-4.123H1.064v2.59A9.996 9.996 0 0010 20z" fill="#34A853"/>
          <path d="M4.405 11.9c-.2-.6-.314-1.24-.314-1.9 0-.66.114-1.3.314-1.9V5.51H1.064A9.996 9.996 0 000 10c0 1.614.386 3.14 1.064 4.49l3.34-2.59z" fill="#FBBC05"/>
          <path d="M10 3.977c1.468 0 2.786.505 3.823 1.496l2.868-2.868C14.955.99 12.695 0 10 0 6.09 0 2.71 2.24 1.064 5.51l3.34 2.59C5.19 5.736 7.395 3.977 10 3.977z" fill="#EA4335"/>
        </svg>
      )
    },
    microsoft: {
      name: 'Microsoft',
      icon: (
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
          <path d="M0 0h9.5v9.5H0V0z" fill="#F25022"/>
          <path d="M10.5 0H20v9.5h-9.5V0z" fill="#7FBA00"/>
          <path d="M0 10.5h9.5V20H0v-9.5z" fill="#00A4EF"/>
          <path d="M10.5 10.5H20V20h-9.5v-9.5z" fill="#FFB900"/>
        </svg>
      )
    },
    apple: {
      name: 'Apple',
      icon: (
        <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
          <path d="M15.362 10.733c-.024-2.413 1.968-3.573 2.058-3.633-1.122-1.64-2.867-1.865-3.489-1.891-1.485-.15-2.898.875-3.652.875-.754 0-1.92-.853-3.156-.83-1.624.024-3.12.943-3.956 2.398-1.686 2.923-.431 7.252 1.211 9.623.803 1.161 1.761 2.465 3.02 2.418 1.213-.048 1.672-.785 3.14-.785 1.468 0 1.88.785 3.156.76 1.305-.024 2.146-1.185 2.95-2.346.929-1.343 1.311-2.641 1.335-2.709-.029-.012-2.561-.982-2.587-3.88h-.03z"/>
          <path d="M12.958 3.19c.67-.811 1.122-1.937 1-3.061-966.89.039-2.136.644-2.828 1.455-.62.72-1.163 1.87-1.018 2.973 1.076.084 2.176-.547 2.846-1.367z"/>
        </svg>
      )
    }
  };
  
  const config = providerConfig[provider];
  
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex items-center justify-center gap-3 w-full px-4 py-3 rounded-xl bg-white border-2 border-[#E5E9ED] text-[#1A2332] font-medium hover:bg-[#F8FAFB] hover:border-[#CBD2D9] active:bg-[#F3F5F7] transition-all duration-200 focus:outline-none focus:ring-4 focus:ring-[#0B4C8F]/10"
    >
      {config.icon}
      <span>Continuer avec {config.name}</span>
    </button>
  );
};
