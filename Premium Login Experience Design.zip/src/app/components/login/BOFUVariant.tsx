import React from 'react';
import { PharmacyLogo } from './PharmacyLogo';
import { LoginFormCard } from './LoginFormCard';

export const BOFUVariant: React.FC = () => {
  return (
    <div className="min-h-screen bg-[#1e293b] flex items-center justify-center p-6">
      <div className="w-full max-w-md space-y-8">
        {/* Logo & Title */}
        <PharmacyLogo showText={true} />
        
        {/* Login Card - Dominant */}
        <LoginFormCard variant="bofu" />
        
        {/* Footer Links - Minimal */}
        <div className="text-center space-y-3">
          <a 
            href="#" 
            className="text-sm text-white/70 hover:text-white transition-colors inline-block"
            onClick={(e) => e.preventDefault()}
          >
            Mot de passe oublié ?
          </a>
        </div>
        
        {/* Security Badge */}
        <div className="p-4 rounded-xl bg-white/5 backdrop-blur-sm border border-white/10 text-center">
          <p className="text-sm text-white/70">
            🔒 Connexion sécurisée • Données chiffrées AES-256
          </p>
        </div>
      </div>
    </div>
  );
};
