import React from 'react';
import { TrendingUp, Users, Building2, Award } from 'lucide-react';

interface StatCardProps {
  value: string;
  label: string;
  icon?: 'trend' | 'users' | 'building' | 'award';
  className?: string;
}

export const StatCard: React.FC<StatCardProps> = ({ 
  value, 
  label, 
  icon = 'users',
  className = '' 
}) => {
  const icons = {
    trend: TrendingUp,
    users: Users,
    building: Building2,
    award: Award
  };
  
  const Icon = icons[icon];
  
  return (
    <div className={`flex items-center gap-4 p-4 rounded-xl bg-white border border-[#E5E9ED] ${className}`}>
      <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-[#0B4C8F] to-[#00A896] flex items-center justify-center shrink-0">
        <Icon className="w-6 h-6 text-white" strokeWidth={2} />
      </div>
      <div>
        <p className="text-2xl font-bold text-[#1A2332]" style={{ letterSpacing: '-0.02em' }}>
          {value}
        </p>
        <p className="text-sm text-[#697586]">{label}</p>
      </div>
    </div>
  );
};
