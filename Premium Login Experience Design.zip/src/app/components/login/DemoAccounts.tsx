import React from 'react';
import { UserCircle2, GraduationCap } from 'lucide-react';
import { PrimaryButton } from './PrimaryButton';

interface DemoAccount {
  type: 'titulaire' | 'etudiant';
  icon: 'user' | 'student';
  email: string;
  label: string;
}

interface DemoAccountsProps {
  onSelectDemo: (email: string) => void;
  className?: string;
}

export const DemoAccounts: React.FC<DemoAccountsProps> = ({ onSelectDemo, className = '' }) => {
  const accounts: DemoAccount[] = [
    {
      type: 'titulaire',
      icon: 'user',
      email: 'titulaire@pharmacie.fr',
      label: 'Titulaire'
    },
    {
      type: 'etudiant',
      icon: 'student',
      email: 'etudiant@email.com',
      label: 'Étudiant'
    }
  ];
  
  return (
    <div className={`space-y-4 ${className}`}>
      <div className="text-center">
        <p className="text-xs font-semibold text-[#94a3b8] uppercase tracking-wide mb-4">
          COMPTES DÉMO
        </p>
        <h3 className="text-sm font-semibold text-[#1e293b] mb-4">
          TESTER L'APPLICATION
        </h3>
      </div>
      
      <div className="space-y-3">
        {accounts.map((account) => (
          <div 
            key={account.type}
            className="flex items-center justify-between p-3 rounded-lg bg-[#f8fafc] border border-[#e2e8f0] hover:bg-white hover:border-[#cbd5e1] transition-all"
          >
            <div className="flex items-center gap-3">
              {account.icon === 'user' ? (
                <UserCircle2 className="w-5 h-5 text-[#10b981]" strokeWidth={2} />
              ) : (
                <GraduationCap className="w-5 h-5 text-[#3b82f6]" strokeWidth={2} />
              )}
              <div>
                <p className="text-sm font-semibold text-[#1e293b]">
                  {account.label}
                </p>
                <p className="text-xs text-[#64748b]">
                  {account.email}
                </p>
              </div>
            </div>
            <PrimaryButton
              variant="primary"
              size="sm"
              onClick={() => onSelectDemo(account.email)}
            >
              Utiliser
            </PrimaryButton>
          </div>
        ))}
      </div>
    </div>
  );
};
