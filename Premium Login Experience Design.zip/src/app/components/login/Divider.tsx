import React from 'react';

interface DividerProps {
  text?: string;
  className?: string;
}

export const Divider: React.FC<DividerProps> = ({ text, className = '' }) => {
  if (text) {
    return (
      <div className={`flex items-center gap-4 ${className}`}>
        <div className="flex-1 h-px bg-[#E5E9ED]" />
        <span className="text-sm text-[#697586] font-medium">{text}</span>
        <div className="flex-1 h-px bg-[#E5E9ED]" />
      </div>
    );
  }
  
  return <div className={`h-px bg-[#E5E9ED] ${className}`} />;
};
