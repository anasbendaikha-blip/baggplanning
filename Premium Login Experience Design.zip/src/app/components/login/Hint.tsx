import React from 'react';
import { Info } from 'lucide-react';

interface HintProps {
  children: React.ReactNode;
  className?: string;
}

export const Hint: React.FC<HintProps> = ({ children, className = '' }) => {
  return (
    <div className={`flex items-start gap-2 p-3 rounded-lg bg-[#dbeafe] border border-[#3b82f6]/20 ${className}`}>
      <Info className="w-4 h-4 text-[#3b82f6] mt-0.5 shrink-0" strokeWidth={2} />
      <p className="text-sm text-[#1e40af] leading-relaxed">
        {children}
      </p>
    </div>
  );
};
