import React from 'react';
import { Shield, Lock, Award, CheckCircle2 } from 'lucide-react';

interface TrustBadgeProps {
  icon?: 'shield' | 'lock' | 'award' | 'check';
  text: string;
  className?: string;
}

export const TrustBadge: React.FC<TrustBadgeProps> = ({ 
  icon = 'shield', 
  text,
  className = '' 
}) => {
  const icons = {
    shield: Shield,
    lock: Lock,
    award: Award,
    check: CheckCircle2
  };
  
  const Icon = icons[icon];
  
  return (
    <div className={`inline-flex items-center gap-2 px-3 py-2 rounded-lg bg-[#E8F1F8] ${className}`}>
      <Icon className="w-4 h-4 text-[#0B4C8F]" strokeWidth={2} />
      <span className="text-sm font-medium text-[#0B4C8F]">
        {text}
      </span>
    </div>
  );
};

interface TrustBarProps {
  className?: string;
}

export const TrustBar: React.FC<TrustBarProps> = ({ className = '' }) => {
  return (
    <div className={`flex flex-wrap items-center gap-3 ${className}`}>
      <TrustBadge icon="lock" text="Données chiffrées" />
      <TrustBadge icon="shield" text="Conforme RGPD" />
      <TrustBadge icon="check" text="Certifié HDS" />
    </div>
  );
};
