import React from 'react';
import { Quote, Star } from 'lucide-react';

interface TestimonialProps {
  quote: string;
  author: string;
  role: string;
  rating?: number;
  className?: string;
}

export const Testimonial: React.FC<TestimonialProps> = ({
  quote,
  author,
  role,
  rating = 5,
  className = ''
}) => {
  return (
    <div className={`relative p-6 rounded-2xl bg-white border border-[#E5E9ED] ${className}`}>
      <Quote className="absolute top-6 right-6 w-8 h-8 text-[#0B4C8F]/10" strokeWidth={2} />
      
      <div className="flex gap-1 mb-4">
        {[...Array(rating)].map((_, i) => (
          <Star key={i} className="w-4 h-4 fill-[#C09856] text-[#C09856]" strokeWidth={0} />
        ))}
      </div>
      
      <p className="text-[#1A2332] mb-4 leading-relaxed">
        "{quote}"
      </p>
      
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#0B4C8F] to-[#00A896] flex items-center justify-center text-white font-semibold">
          {author.charAt(0)}
        </div>
        <div>
          <p className="font-semibold text-[#1A2332] text-sm">{author}</p>
          <p className="text-sm text-[#697586]">{role}</p>
        </div>
      </div>
    </div>
  );
};
