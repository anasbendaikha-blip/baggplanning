import React from 'react';

interface PartnerLogosProps {
  className?: string;
}

export const PartnerLogos: React.FC<PartnerLogosProps> = ({ className = '' }) => {
  const partners = [
    { name: 'Ordre National des Pharmaciens', abbr: 'ONP' },
    { name: 'AP-HP', abbr: 'AP-HP' },
    { name: 'ARS', abbr: 'ARS' },
    { name: 'ANSM', abbr: 'ANSM' }
  ];
  
  return (
    <div className={className}>
      <p className="text-sm text-[#697586] mb-4 text-center">
        Approuvé et utilisé par
      </p>
      <div className="flex flex-wrap items-center justify-center gap-6">
        {partners.map((partner) => (
          <div 
            key={partner.abbr}
            className="flex items-center justify-center px-4 py-2 rounded-lg bg-white border border-[#E5E9ED] min-w-[80px]"
          >
            <span className="text-sm font-semibold text-[#697586]">
              {partner.abbr}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};
