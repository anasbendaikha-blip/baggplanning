import React from 'react';
import { CheckCircle2 } from 'lucide-react';

interface Feature {
  text: string;
}

interface FeatureListProps {
  features: Feature[];
  className?: string;
}

export const FeatureList: React.FC<FeatureListProps> = ({ features, className = '' }) => {
  return (
    <ul className={`space-y-3 ${className}`}>
      {features.map((feature, index) => (
        <li key={index} className="flex items-start gap-3">
          <CheckCircle2 
            className="w-5 h-5 text-[#00A896] shrink-0 mt-0.5" 
            strokeWidth={2.5} 
          />
          <span className="text-[#1A2332] leading-relaxed">
            {feature.text}
          </span>
        </li>
      ))}
    </ul>
  );
};
