import React from 'react';
import { Calendar } from 'lucide-react';

interface PharmacyLogoProps {
  className?: string;
  showText?: boolean;
}

export const PharmacyLogo: React.FC<PharmacyLogoProps> = ({ 
  className = '',
  showText = true
}) => {
  return (
    <div className={`flex flex-col items-center gap-4 ${className}`}>
      {/* Icon with gradient background - Style BaggPlanning */}
      <div className="relative">
        <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-[#10b981] to-[#059669] flex items-center justify-center shadow-lg">
          <Calendar className="w-10 h-10 text-white" strokeWidth={2} />
        </div>
        {/* Badge number like calendar */}
        <div className="absolute bottom-2 right-2 w-8 h-8 rounded-lg bg-white flex items-center justify-center shadow-md">
          <span className="text-[#10b981] font-bold text-sm">17</span>
        </div>
      </div>
      
      {showText && (
        <div className="text-center">
          <h1 className="text-3xl font-bold text-white mb-1 tracking-tight">
            PharmaCare
          </h1>
          <p className="text-sm text-white/70">
            Gestion des plannings de la pharmacie
          </p>
        </div>
      )}
    </div>
  );
};
