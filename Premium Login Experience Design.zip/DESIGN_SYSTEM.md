# Design System Premium Pharma - PharmaCare

## 🎨 Palette de couleurs

### Couleurs primaires

#### Bleu médical profond (Confiance, professionnalisme)
```css
--primary: #0B4C8F
--primary-hover: #094180
--primary-active: #073565
--primary-light: #E8F1F8
```

**Usage :** CTA principaux, liens, focus states, éléments de brand

**Psychologie :** Confiance, sécurité, expertise médicale, stabilité

---

#### Vert menthe médical (Santé, apaisement)
```css
--secondary: #00A896
--secondary-hover: #008C7D
--secondary-active: #007569
--secondary-light: #E6F7F5
```

**Usage :** Accents, success states, icônes de validation, features positives

**Psychologie :** Santé, bien-être, calme, validation, croissance

---

#### Or discret (Premium, excellence)
```css
--accent: #C09856
--accent-light: #F8F3EB
```

**Usage :** Highlights premium, étoiles de notation, badges spéciaux

**Psychologie :** Excellence, qualité, valeur, prestige discret

---

### Neutres sophistiqués

```css
--neutral-50: #F8FAFB   /* Backgrounds très clairs */
--neutral-100: #F3F5F7  /* Backgrounds clairs */
--neutral-200: #E5E9ED  /* Borders, dividers */
--neutral-300: #CBD2D9  /* Borders hover */
--neutral-400: #9AA5B1  /* Disabled text */
--neutral-500: #697586  /* Secondary text */
--neutral-600: #4B5768  /* Primary text light */
--neutral-700: #364152  /* Primary text */
--neutral-800: #1F2937  /* Headings */
--neutral-900: #1A2332  /* Headings dark */
```

---

### États sémantiques

#### Success (Succès, validation)
```css
--success: #059669
--success-foreground: #FFFFFF
--success-light: #ECFDF5
```

#### Error (Erreur, attention)
```css
--destructive: #DC2626
--destructive-foreground: #FFFFFF
--destructive-light: #FEF2F2
```

#### Warning (Avertissement)
```css
--warning: #F59E0B
--warning-foreground: #FFFFFF
--warning-light: #FFFBEB
```

#### Info (Information)
```css
--info: #0EA5E9
--info-foreground: #FFFFFF
--info-light: #F0F9FF
```

---

## 🔤 Typographie

### Famille de polices
```css
font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
```

**Raison :** Inter est une police sans-serif moderne, très lisible, conçue pour les interfaces numériques, avec d'excellentes propriétés d'espacement.

---

### Hiérarchie typographique

#### H1 - Titre principal
```css
font-size: 2rem (32px)
font-weight: 600 (semibold)
line-height: 1.25
letter-spacing: -0.02em
color: var(--neutral-900)
```

**Usage :** Titre principal de page, hero titles

---

#### H2 - Titre secondaire
```css
font-size: 1.5rem (24px)
font-weight: 600 (semibold)
line-height: 1.33
letter-spacing: -0.01em
color: var(--neutral-900)
```

**Usage :** Titres de sections, titres de cartes importantes

---

#### H3 - Titre tertiaire
```css
font-size: 1.25rem (20px)
font-weight: 600 (semibold)
line-height: 1.4
color: var(--neutral-900)
```

**Usage :** Sous-sections, titres de composants

---

#### H4 - Titre quaternaire
```css
font-size: 1.125rem (18px)
font-weight: 600 (semibold)
line-height: 1.5
color: var(--neutral-800)
```

**Usage :** Petits titres, headers de listes

---

#### Body - Texte standard
```css
font-size: 1rem (16px)
font-weight: 400 (normal)
line-height: 1.6
color: var(--neutral-700)
```

**Usage :** Paragraphes, textes de description

---

#### Body Large - Texte accentué
```css
font-size: 1.125rem (18px)
font-weight: 400 (normal)
line-height: 1.6
color: var(--neutral-700)
```

**Usage :** Introductions, sous-titres importants

---

#### Body Small - Texte secondaire
```css
font-size: 0.875rem (14px)
font-weight: 400 (normal)
line-height: 1.5
color: var(--neutral-500)
```

**Usage :** Helper texts, labels secondaires, captions

---

#### Label - Étiquettes de formulaire
```css
font-size: 0.875rem (14px)
font-weight: 500 (medium)
line-height: 1.5
letter-spacing: 0.01em
color: var(--neutral-800)
```

**Usage :** Labels de champs, titres de composants

---

#### Button - Texte de boutons
```css
font-size: 1rem (16px)
font-weight: 500 (medium)
line-height: 1.5
```

**Usage :** CTA, boutons

---

### Graisses (Font weights)

```css
--font-weight-light: 300     /* Rarement utilisé */
--font-weight-normal: 400    /* Texte standard */
--font-weight-medium: 500    /* Labels, boutons */
--font-weight-semibold: 600  /* Titres */
--font-weight-bold: 700      /* Emphase forte */
```

---

## 📐 Spacing System (Grille 8pt)

```css
--space-1: 0.25rem   /* 4px */
--space-2: 0.5rem    /* 8px */
--space-3: 0.75rem   /* 12px */
--space-4: 1rem      /* 16px */
--space-5: 1.25rem   /* 20px */
--space-6: 1.5rem    /* 24px */
--space-8: 2rem      /* 32px */
--space-10: 2.5rem   /* 40px */
--space-12: 3rem     /* 48px */
--space-16: 4rem     /* 64px */
--space-20: 5rem     /* 80px */
--space-24: 6rem     /* 96px */
```

### Règles d'application

- **Composants internes :** multiples de 4px (space-1, space-2, space-3, space-4)
- **Espaces entre composants :** multiples de 8px (space-2, space-4, space-6, space-8)
- **Sections :** multiples de 16px (space-8, space-12, space-16)

---

## 🔲 Border Radius

```css
--radius-sm: 0.5rem    /* 8px - Petits éléments */
--radius-md: 0.625rem  /* 10px - Éléments moyens */
--radius-lg: 0.75rem   /* 12px - Cartes, inputs */
--radius-xl: 1rem      /* 16px - Grandes cartes */
--radius-2xl: 1.5rem   /* 24px - Panels, modals */
```

### Usage recommandé

- **Inputs, selects :** `radius-lg` (12px)
- **Boutons :** `radius-lg` (12px)
- **Cartes standards :** `radius-xl` (16px)
- **Grandes cartes / Panels :** `radius-2xl` (24px)
- **Badges, pills :** `radius-full` (9999px)

---

## 🌑 Ombres (Shadows)

```css
--shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
--shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
--shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
--shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1);
```

### Usage

- **Aucune ombre :** Éléments plats, inline
- **shadow-sm :** Boutons au repos, inputs
- **shadow-md :** Cartes standards, dropdowns
- **shadow-lg :** Modales, grandes cartes de login
- **shadow-xl :** Panels flottants, overlays

### Ombres au hover

```css
/* Ajouter une ombre plus prononcée au hover pour effet de profondeur */
button:hover {
  box-shadow: var(--shadow-md);
}
```

---

## 🎭 États interactifs

### Focus
```css
focus:outline-none 
focus:ring-4 
focus:ring-[color]/20
```

**Principe :** Ring de 4px avec 20% d'opacité de la couleur principale

---

### Hover
```css
/* Boutons primaires */
hover:bg-[color-hover]
hover:shadow-md

/* Liens */
hover:text-[color-hover]
hover:underline

/* Cartes */
hover:border-[color]
hover:shadow-lg
```

**Principe :** Transition douce (200ms), changement subtil

---

### Active/Pressed
```css
active:bg-[color-active]
active:scale-[0.98]
```

**Principe :** Légère compression visuelle, couleur plus foncée

---

### Disabled
```css
disabled:opacity-60
disabled:cursor-not-allowed
```

**Principe :** Réduction d'opacité, curseur approprié

---

## 🧩 Composants

### 1. Bouton Principal (Primary Button)

#### Variant Primary (CTA principal)
```css
Background: var(--primary)
Text: white
Padding: 14px 24px (py-3.5 px-6)
Border-radius: 12px
Font-weight: 500
Hover: var(--primary-hover) + shadow-md
Focus: ring-4 ring-primary/20
Active: var(--primary-active) + scale-98
```

#### Variant Secondary
```css
Background: var(--secondary)
Text: white
/* Autres propriétés identiques */
```

#### Variant Outline
```css
Background: white
Border: 2px solid var(--primary)
Text: var(--primary)
Hover: bg-primary-light
```

---

### 2. Input Field (Champ de saisie)

#### État Default
```css
Background: white
Border: 2px solid var(--neutral-300)
Padding: 14px 16px (py-3.5 px-4)
Border-radius: 12px
Font-size: 16px
```

#### État Focus
```css
Border: 2px solid var(--primary)
Ring: 4px ring-primary/10
```

#### État Error
```css
Border: 2px solid var(--destructive)
Ring: 4px ring-destructive/20
```

#### État Success
```css
Border: 2px solid var(--success)
Ring: 4px ring-success/20
```

---

### 3. Card (Carte)

#### Card Standard
```css
Background: white
Border: 1px solid var(--neutral-200)
Border-radius: 16px
Padding: 24px (p-6)
Shadow: var(--shadow-md)
```

#### Card Login (Grande carte)
```css
Max-width: 480px
Background: white
Border: 1px solid var(--neutral-200)
Border-radius: 16px
Padding: 32px (p-8)
Shadow: var(--shadow-xl)
```

---

### 4. Trust Badge

```css
Background: var(--primary-light)
Border-radius: 8px
Padding: 8px 12px (py-2 px-3)
Display: inline-flex
Gap: 8px
Icon: var(--primary)
Text: var(--primary) font-medium
```

---

### 5. Divider

#### Avec texte
```css
Line: 1px solid var(--neutral-200)
Text: text-sm text-neutral-500 font-medium
Gap: 16px
```

#### Sans texte
```css
Height: 1px
Background: var(--neutral-200)
```

---

### 6. Testimonial Card

```css
Background: white
Border: 1px solid var(--neutral-200)
Border-radius: 16px
Padding: 24px
Quote icon: var(--primary)/10
Stars: var(--accent)
Avatar: gradient primary to secondary
```

---

### 7. Stat Card

```css
Background: white
Border: 1px solid var(--neutral-200)
Border-radius: 12px
Padding: 16px
Icon container: gradient primary to secondary, 48x48px, rounded-lg
Value: text-2xl font-bold
Label: text-sm text-neutral-500
```

---

## 🎨 Gradients

### Gradient Primary
```css
background: linear-gradient(135deg, #0B4C8F 0%, #00A896 100%);
```

**Usage :** Backgrounds premium, icônes de features

---

### Gradient Subtle (Backgrounds)
```css
background: linear-gradient(135deg, #F8FAFB 0%, #F3F5F7 100%);
```

**Usage :** Backgrounds de page

---

### Gradient Accent Light
```css
background: linear-gradient(90deg, #E8F1F8 0%, #E6F7F5 100%);
```

**Usage :** Banners, highlights

---

## 📱 Breakpoints Responsive

```css
/* Mobile */
@media (max-width: 640px) { ... }

/* Tablet */
@media (min-width: 641px) and (max-width: 1024px) { ... }

/* Desktop */
@media (min-width: 1025px) { ... }

/* Large Desktop */
@media (min-width: 1440px) { ... }
```

### Adaptations

#### Mobile (< 640px)
- Layout single column
- Padding réduit (16px au lieu de 32px)
- Titres plus petits (H1: 1.75rem)
- Boutons full-width

#### Tablet (641-1024px)
- Layout hybride (parfois split, parfois stack)
- Padding moyen (24px)
- Typographie standard

#### Desktop (> 1025px)
- Split layout (50/50)
- Padding maximum (48-64px)
- Tous les détails visibles

---

## ♿ Accessibilité

### Contrastes

Tous les contrastes respectent **WCAG 2.1 AA minimum** :

- Texte normal : ratio 4.5:1
- Texte large : ratio 3:1
- Éléments UI : ratio 3:1

### États de focus

- Ring visible sur tous les éléments interactifs
- Navigation clavier complète
- Skip links disponibles

### Textes alternatifs

- Tous les éléments visuels ont un alt ou aria-label
- Icônes décoratives : aria-hidden="true"

---

## 🎯 Principes de design

### 1. Fluence cognitive
- Une action principale par écran
- Hiérarchie visuelle claire
- Espacement généreux

### 2. Cohérence
- Composants réutilisables
- Patterns répétés
- Nomenclature uniforme

### 3. Feedback visuel
- États visibles (hover, focus, active, disabled)
- Animations subtiles (200ms)
- Messages d'erreur inline

### 4. Premium discret
- Finitions soignées
- Alignements parfaits
- Détails attentionnés

### 5. Confiance médicale
- Palette sobre et professionnelle
- Typographie lisible
- Pas de distractions

---

## 🔧 Tokens CSS (Variables)

```css
:root {
  /* Colors */
  --primary: #0B4C8F;
  --secondary: #00A896;
  --accent: #C09856;
  
  /* Spacing */
  --space-base: 8px;
  
  /* Radius */
  --radius: 0.75rem;
  
  /* Shadows */
  --shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
  
  /* Transitions */
  --transition-fast: 150ms ease;
  --transition-base: 200ms ease;
  --transition-slow: 300ms ease;
}
```

---

## 📦 Structure des composants

```
/components
  /login
    - PharmacyLogo.tsx
    - TrustBadge.tsx
    - InputField.tsx
    - PrimaryButton.tsx
    - SocialLoginButton.tsx
    - Divider.tsx
    - Testimonial.tsx
    - StatCard.tsx
    - PartnerLogos.tsx
    - FeatureList.tsx
    - LoginFormCard.tsx
    - TOFUVariant.tsx
    - MOFUVariant.tsx
    - BOFUVariant.tsx
```

---

**Version:** 1.0  
**Date:** Janvier 2026  
**Marque:** PharmaCare  
**Secteur:** Pharmacie / Santé professionnelle
