# Exemples d'utilisation - PharmaCare Login

## 🎯 Guide rapide d'utilisation

### Navigation entre les variantes

#### 1. Via les boutons Pills
Cliquez sur les boutons en haut de l'écran :
- **TOFU** - Pour la découverte
- **MOFU** - Pour la considération
- **BOFU** - Pour la conversion

#### 2. Via les flèches de navigation
Utilisez les flèches ← → dans la barre supérieure (desktop uniquement)

#### 3. Via le clavier
Appuyez sur les touches :
- `←` : Variante précédente
- `→` : Variante suivante

---

## 📱 Tester le responsive

### Sur votre navigateur
1. Ouvrir DevTools (F12)
2. Activer le mode responsive (Ctrl/Cmd + Shift + M)
3. Tester les breakpoints :
   - **375px** : iPhone SE
   - **768px** : iPad
   - **1440px** : Desktop

### Points à observer
- Logo affiché différemment selon le device
- Layout passe de split à stack sur mobile
- Navigation compacte sur mobile
- Features/stats déplacés en bas sur mobile
- Trust badges adaptés

---

## 🧪 Tester les fonctionnalités

### Formulaire de connexion

#### Email
1. Cliquer dans le champ "Adresse email professionnelle"
2. Observer le focus (bordure bleue + ring)
3. Taper une adresse invalide : "test"
4. Observer l'erreur inline en rouge
5. Taper une adresse valide : "test@pharmacie.fr"
6. Observer la disparition de l'erreur

#### Mot de passe
1. Cliquer dans le champ "Mot de passe"
2. Observer le focus
3. Taper un mot de passe
4. Cliquer sur l'icône œil pour révéler/cacher
5. Observer le toggle fonctionner

#### Checkbox "Rester connecté"
1. Cocher/décocher la checkbox
2. Observer l'état visuel

#### Soumission
1. Remplir email et mot de passe
2. Cliquer sur "Se connecter"
3. Observer :
   - Bouton en état loading (spinner)
   - Texte change en "Connexion en cours..."
   - Après 1.5s, retour à l'état normal

### Liens secondaires
- **Mot de passe oublié** : Au-dessus du bouton
- **Créer un compte** : En bas de la carte
- **Besoin d'aide** : Avec icône help

### SSO (Social Login)
Position variable selon variante :
- **TOFU** : En bas du formulaire
- **MOFU** : En haut du formulaire
- **BOFU** : En haut du formulaire

Boutons disponibles :
- Google
- Microsoft
- Apple (iOS only, visuellement)

---

## 🎨 Observer le design system

### Couleurs
Regardez les variations de couleurs selon les contextes :
- **Primaire (#0B4C8F)** : CTA, liens, focus
- **Secondaire (#00A896)** : Checkmarks, success
- **Accent (#C09856)** : Étoiles, badges premium
- **Neutres** : Textes, borders, backgrounds

### Espacements
Tout est basé sur une grille 8pt :
- 4px, 8px, 12px, 16px, 24px, 32px, etc.
- Observer la cohérence entre les composants

### Typographie
- **H1** : Gros titres (32px, semibold)
- **H2** : Titres de cartes (24px, semibold)
- **Body** : Textes standards (16px, normal)
- **Small** : Helper texts (14px, normal)

### Ombres
- Cartes : shadow-md
- Carte de login : shadow-xl
- Boutons au hover : shadow-md

### Border radius
- Inputs/Buttons : 12px
- Cartes : 16px
- Badges : 8px

---

## 🧠 Comparer les variantes

### TOFU vs MOFU vs BOFU

#### Contenu du panneau gauche
| Élément | TOFU | MOFU | BOFU |
|---------|------|------|------|
| Background | Gradient bleu/vert | Blanc | Gradient bleu |
| Message principal | Hero avec promesse | Stats + témoignage | Bienvenue simple |
| Features | 3 bullets | 4 stats cards | 3 mini-features |
| Preuves | Aucune | Testimonial + logos | 1 bandeau sécurité |
| Abstraction | Illustration | Logos partenaires | Minimaliste |

#### Position du SSO
- **TOFU** : Après le formulaire (découverte d'abord)
- **MOFU** : Avant le formulaire (raccourci)
- **BOFU** : Avant le formulaire (friction min)

#### Copywriting
- **TOFU** : "Accédez à votre espace professionnel"
- **MOFU** : "Connectez-vous en toute sécurité"
- **BOFU** : "Accéder à mon espace"

---

## 🔍 Tester les états

### États des inputs

#### État Default
- Border grise neutre (#CBD2D9)
- Background blanc
- Placeholder gris clair

#### État Focus
- Border bleue (#0B4C8F)
- Ring bleu (4px, 10% opacity)
- Transition douce (200ms)

#### État Error
- Border rouge (#DC2626)
- Ring rouge (4px, 20% opacity)
- Icône d'alerte à droite
- Message d'erreur en dessous

#### État Success (si implémenté)
- Border verte (#059669)
- Ring vert (4px, 20% opacity)
- Icône de validation à droite

### États des boutons

#### État Default (Primary)
- Background bleu (#0B4C8F)
- Texte blanc
- Shadow-sm

#### État Hover
- Background bleu foncé (#094180)
- Shadow-md
- Cursor pointer

#### État Active (pressed)
- Background encore plus foncé (#073565)
- Scale 98% (légère compression)

#### État Loading
- Spinner animé
- Texte "Connexion en cours..."
- Disabled automatiquement

#### État Disabled
- Opacity 60%
- Cursor not-allowed
- Pas de hover

---

## 📸 Captures d'écran recommandées

### Pour documentation
1. **Desktop TOFU** - Vue complète
2. **Desktop MOFU** - Vue complète
3. **Desktop BOFU** - Vue complète
4. **Mobile TOFU** - Scroll complet
5. **Mobile MOFU** - Scroll complet
6. **Mobile BOFU** - Scroll complet
7. **État d'erreur** - Champ email invalide
8. **État de chargement** - Bouton en loading
9. **Focus visible** - Input en focus pour accessibilité

### Pour tests A/B
1. Variante A vs B du CTA
2. Position SSO en haut vs en bas
3. Avec vs sans preuves sociales
4. Avec vs sans bannière d'information

---

## 🎯 Scénarios utilisateur

### Scénario 1 : Utilisateur nouveau (TOFU)
1. Arrive sur la page
2. Lit le titre : "La plateforme qui simplifie..."
3. Découvre les 3 bénéfices
4. Voit "15 heures par semaine" (quantification)
5. Lit les badges de confiance
6. Remplit le formulaire
7. Voit le SSO en bas (alternative)
8. Se connecte

**Objectif atteint** : Compréhension claire de la valeur

### Scénario 2 : Utilisateur en considération (MOFU)
1. Arrive sur la page
2. Voit "12 000+ utilisateurs"
3. Lit les 4 statistiques
4. Lit le témoignage de Dr. Sophie Martin
5. Reconnaît les logos partenaires (ONP, AP-HP)
6. Se rassure avec les badges RGPD
7. Choisit SSO Google (en haut, visible)
8. Se connecte

**Objectif atteint** : Confiance établie

### Scénario 3 : Utilisateur existant (BOFU)
1. Arrive sur la page
2. Lit "Bienvenue"
3. Voit immédiatement le formulaire
4. Utilise SSO ou email (son choix habituel)
5. Se connecte rapidement

**Objectif atteint** : Friction minimale

---

## 🧪 Tests de validation

### Checklist UX
- [ ] Tous les champs sont accessibles au clavier (Tab)
- [ ] Le focus est visible sur tous les éléments
- [ ] Les messages d'erreur sont clairs et constructifs
- [ ] Le bouton de soumission indique clairement l'action
- [ ] Les liens secondaires sont facilement identifiables
- [ ] Le toggle password fonctionne
- [ ] L'état de chargement est visible
- [ ] La navigation entre variantes est fluide
- [ ] Le responsive fonctionne sur tous les devices

### Checklist Accessibilité
- [ ] Contrastes minimums respectés (4.5:1)
- [ ] Labels associés aux inputs
- [ ] Messages d'erreur liés aux champs (aria-describedby)
- [ ] Navigation clavier complète
- [ ] Focus trap dans le formulaire (si modal)
- [ ] Annonce des changements d'état (ARIA live regions)
- [ ] Textes alternatifs pour les icônes décoratives

### Checklist Performance
- [ ] Page charge en < 2s
- [ ] Pas de lag lors du typing
- [ ] Transitions fluides (60fps)
- [ ] Pas de flash de contenu non stylé (FOUC)
- [ ] Images optimisées (si ajoutées)

---

## 💡 Tips d'utilisation

### Pour les designers
1. Utiliser le mode "Masquer" de la bannière pour voir le design pur
2. Observer les micro-interactions (hover, focus, active)
3. Noter les spacings entre éléments (grille 8pt)
4. Examiner la hiérarchie typographique
5. Tester le design sur différents contextes (clair/sombre)

### Pour les développeurs
1. Inspecter les composants dans DevTools
2. Observer la structure des classes Tailwind
3. Regarder les props TypeScript
4. Tester la validation de formulaire
5. Modifier les couleurs dans theme.css pour tester

### Pour les PO/PM
1. Comparer les 3 variantes côte à côte (captures)
2. Noter les différences de copywriting
3. Identifier les éléments de preuve sociale
4. Évaluer la charge cognitive de chaque variante
5. Définir quelle variante pour quelle audience

### Pour les testeurs
1. Tester tous les champs avec données invalides
2. Tester la navigation clavier complète
3. Tester sur devices réels (pas que émulateur)
4. Tester avec screen reader
5. Tester en mode zoom 200%

---

## 🎨 Personnalisation rapide

### Changer les couleurs
Éditer `/src/styles/theme.css` :
```css
--primary: #VOTRE_COULEUR;
--secondary: #VOTRE_COULEUR;
--accent: #VOTRE_COULEUR;
```

### Changer le logo
Éditer `/src/app/components/login/PharmacyLogo.tsx` :
- Modifier le SVG
- Ou importer une image

### Changer les textes
Référer à `/COPYWRITING.md` pour tous les textes
Éditer directement dans les composants de variante

### Changer la police
Éditer `/src/styles/fonts.css` :
```css
@import url('...');
```
Puis mettre à jour theme.css :
```css
font-family: 'VotrePolice', ...
```

---

## 📱 Tester sur vrais devices

### iOS (Safari)
- Vérifier le comportement du toggle password
- Tester le zoom auto sur focus (16px min)
- Vérifier les fonts rendering
- Tester le SSO Apple

### Android (Chrome)
- Vérifier l'autocomplete
- Tester le clavier virtuel
- Vérifier les transitions
- Tester les boutons SSO

### Desktop
- Chrome : DevTools, Lighthouse
- Firefox : Accessibility inspector
- Safari : Performance
- Edge : Compatibility

---

## 🔧 Debugging

### Problème : Le formulaire ne se soumet pas
1. Vérifier la console (F12)
2. Regarder si l'email est valide
3. Vérifier si le password est rempli
4. Observer l'état loading

### Problème : Le responsive ne fonctionne pas
1. Vérifier le viewport meta tag
2. Tester dans DevTools responsive mode
3. Vider le cache navigateur
4. Vérifier les classes Tailwind (lg:, sm:, etc.)

### Problème : Les couleurs ne s'affichent pas
1. Vérifier theme.css est bien chargé
2. Inspecter l'élément dans DevTools
3. Vérifier les custom properties CSS
4. Forcer un rebuild

---

## 📊 Métriques à observer

### Google Analytics Events
```javascript
// Navigation
'variant_view' - TOFU/MOFU/BOFU viewed

// Form
'form_start' - User started typing
'form_error' - Validation error occurred
'form_submit' - Form submitted
'login_success' - Login successful

// Social
'sso_click' - SSO button clicked
```

### Hotjar / FullStory
- Heatmaps des clics
- Session recordings
- Rage clicks (erreurs)
- Form abandonment

---

**Version:** 1.0  
**Date:** Janvier 2026  
**Prochaine mise à jour:** Selon feedback utilisateurs
